﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAnimales
{
    class Caballo : Mamiferos, IMamiferosTerrestres
    {

        public void Galopar()
        {
            Console.WriteLine("El caballo está galopando");
        }
        public override void getNombre(string Nombre)
        {
            Console.WriteLine(Nombre);

        }

        public void NumerodePatas(int NumeroPatas)
        {
            Console.WriteLine("Numero de patas: " + NumeroPatas);
        }
    }
}
