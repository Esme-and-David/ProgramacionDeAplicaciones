﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAnimales
{
    public abstract class Animales
    {
        public void Respirar()
        {
            Console.WriteLine("Respira");

        }
        public abstract void getNombre(string Nombre);

    }
}
