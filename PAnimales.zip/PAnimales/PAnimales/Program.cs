﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAnimales
{
    class Program
    {
        static void Main(string[] args)
        {


            Ballena ball = new Ballena();
            ball.getNombre(Nombre: "Wili");
            ball.Nadar();

            Console.Read();


            Console.Read();

            Caballo cab = new Caballo();

            cab.getNombre(Nombre:"Burro");
            cab.Galopar();
            cab.CuidarsusCrias();
            cab.Pensar();
            cab.Respirar();
            cab.NumerodePatas(NumeroPatas: 4);

            Console.Read();

            Console.Read();
            Gorila gori = new Gorila();

            gori.getNombre(Nombre: "Pancho");
            gori.Trepar();
            gori.CuidarsusCrias();
            gori.Pensar();
            gori.Respirar();
            gori.NumerodePatas(NumeroPatas: 4);

            Console.Read();


            Console.Read();

            Humano hum = new Humano();

            hum.getNombre(Nombre: "Dani");
            hum.pensar();
            hum.Respirar();
            hum.NumerodePatas(NumeroPatas: 2);

            Console.Read();

            Console.Read();

            Lagartija lag = new Lagartija();

            lag.getNombre(Nombre: "Zoe");
            lag.Respirar();
            lag.NumerodePatas(NumeroPatas: 4);

            Console.Read();

        }
    }
}
