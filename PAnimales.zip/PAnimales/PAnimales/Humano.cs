﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAnimales
{
    class Humano : Mamiferos, IMamiferosTerrestres
    {

        public void pensar()
        {
            Console.WriteLine("El humano piensa");
        }


        public override void getNombre(string Nombre)
        {
            Console.WriteLine(Nombre);

        }

        public void NumerodePatas(int NumeroPatas)
        {
            Console.WriteLine("Numero de patas: " + NumeroPatas);
        }
    }
}
