﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAnimales
{
    class Mamiferos : Animales
    {
        public void Pensar()
        {
            Console.WriteLine("Piensa");
        }
        public override void getNombre(string Nombre)
        {
            Console.WriteLine(Nombre);

        }

        public void CuidarsusCrias()
        {
            Console.WriteLine("Está cuidando sus crías");
        }
    }
}
