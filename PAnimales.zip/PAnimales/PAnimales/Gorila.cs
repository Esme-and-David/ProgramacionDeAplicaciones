﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAnimales
{
    class Gorila : Mamiferos, IMamiferosTerrestres
    {
        public void Trepar()
        {
            Console.WriteLine("El gorila está trepando");
        }

        public override void getNombre(string Nombre)
        {
            Console.WriteLine(Nombre);

        }

        public void NumerodePatas(int NumeroPatas)
        {
            Console.WriteLine("Numero de patas: " + NumeroPatas);
        }
    }
}
