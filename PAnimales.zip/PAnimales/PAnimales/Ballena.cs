﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAnimales
{
    class Ballena : Mamiferos
    {
        public void Nadar()
        {
            Console.WriteLine("La ballena está nadando");
        }
    }
}
