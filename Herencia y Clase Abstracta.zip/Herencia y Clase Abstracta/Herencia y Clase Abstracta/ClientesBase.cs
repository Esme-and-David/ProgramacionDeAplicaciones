﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Herencia_y_Clase_Abstracta
{
    public class ClientesBase: ClientesAbst
    {
        public ClientesBase()
        {
            Id = 0;
            Nombre = string.Empty;
            Clave = string.Empty;
            RFC = string.Empty;
            NombreContacto = string.Empty;
        }

        public ClientesBase(int pId, string pNombre, string pClave, string pRFC, string pNombreContacto)
        {
            Id = pId;
            Nombre = pNombre;
            Clave = pClave;
            RFC = pRFC;
            NombreContacto = pNombreContacto;
        }




        public override int Id { get; set; }

        public override string Nombre { get; set; }

        public override string Clave { get; set; }

        public override string RFC { get; set; }

        public override string NombreContacto { get; set; }
    } 
}
