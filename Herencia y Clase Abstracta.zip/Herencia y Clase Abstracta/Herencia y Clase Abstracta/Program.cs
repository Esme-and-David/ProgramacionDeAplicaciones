﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Herencia_y_Clase_Abstracta
{
    class Program
    {
        static void Main(string[] args)
        {
            ClientesBase clienB = new ClientesBase(22, "David Mendoza", "dma4587", "MEAD971105", "Esmeralda Morales");

            Console.WriteLine("Nombre: " + clienB.Nombre);
            Console.WriteLine("Clave: " + clienB.Clave);
            Console.WriteLine("RFC: " + clienB.RFC);
            Console.WriteLine("Nombre del contacto: " + clienB.NombreContacto);

            Console.ReadKey();


        }
    }
}
