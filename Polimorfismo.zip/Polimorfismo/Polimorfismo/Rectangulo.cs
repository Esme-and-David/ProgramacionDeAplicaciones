﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polimorfismo
{
    class Rectangulo
    {
        public void Area (int Base, int Altura) //Método Area para el rectangulo
        {
            Console.WriteLine("El área del rectangulo " + (Base * Altura));

        }
    }
}
