﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polimorfismo
    /*Es la capacidad que tiene un clase de utilizar sus métodos de diferente forma*/
{
    class Program
    {
        static void Main(string[] args)
        {
            Rectangulo rec = new Rectangulo();
            rec.Area(34,56);

            Triangulo tri = new Triangulo();
            tri.Area(34,56);


            Console.ReadKey();
        }
    }
}
