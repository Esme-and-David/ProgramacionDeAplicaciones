﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polimorfismo
{
    class Triangulo:Rectangulo
    {
        public void Area (int Base, int Altura) //Se implementa el mismo método del rectangulo
                                               //pero se imlementa de manera diferente en el triangulo
        {
            Console.WriteLine("El área del triangulo es: " + (Base * Altura) / 2);

        }
    }
}
