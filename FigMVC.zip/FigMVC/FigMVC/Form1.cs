﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FigMVC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            label1.Text = "altura";
            label2.Text = "base";
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            int a = 0, b = 0;
            a = Convert.ToInt32(textBox1.Text);
            b = Convert.ToInt32(textBox2.Text);
            Control.Controlador.CrearRectangulo(a, b);// enviamos los parametros 
            textBox3.Text = Convert.ToString(Control.Controlador.obtenerControl().ConsultarPerimetro());
            textBox4.Text = Convert.ToString(Control.Controlador.obtenerControl().ConsultarArea());



        }

        private void Button2_Click(object sender, EventArgs e)
        {
            label1.Text = "lado";
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }
    }
    }

