﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Singleton
{
    class Program
    {
        static void Main(string[] args)
        {
         singleton m = new singleton(1);
         for (int i = 0; i < 10; i++)
             m.DiNumero();

            }
        }
    }
