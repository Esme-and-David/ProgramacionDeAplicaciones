﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Singleton
{
    class singleton
    {

        private static int m_cuenta = 1;
  
     private int m_numero;

     public singleton(int num)
     {
         m_cuenta++;
            m_numero = num;
     }
     public void DiNumero()
     {
         Console.WriteLine(m_numero++.ToString());
            Console.ReadLine();

        }
    }
}
